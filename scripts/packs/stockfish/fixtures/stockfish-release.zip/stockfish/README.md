# Stockfish (fixture)
A placeholder standing in for the release's README.
