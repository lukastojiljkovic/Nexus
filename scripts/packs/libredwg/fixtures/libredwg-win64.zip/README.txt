LibreDWG fixture readme.
